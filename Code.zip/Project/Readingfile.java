import java.io.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

public class Readingfile {

    public static HashMap<String,music> readfile() {

        //specify file path
        String filePath = "listofsong";

        HashMap<String,music> libraryMap = new HashMap<String, music>();

        try {

            //reading from file
            String line;
            BufferedReader reader = new BufferedReader(new FileReader(filePath));

            while ((line = reader.readLine()) != null) {

                //Display on new line  //creating array thearray
                String[] thearray = line.split("\t");

                String songtitle =thearray[0];
                String artist = thearray[1];
                String playingtime=thearray[2];
                String videofilename=thearray[3];

                //create new object and populating with the 4 attributes
                music object = new music(thearray[0],thearray[1],Integer.parseInt(thearray[2]),thearray[3]);
                libraryMap.put(object.getSongtitle(),object);

            } //end while loop

        } //end try
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) { // The compiler warns that all the Exceptions possibly
            // caught by IOException are already caught even though
            // an IOException is not necessarily a FNFException
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return libraryMap;
    }

}
