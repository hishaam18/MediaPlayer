import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.*;
import java.util.HashMap;

public class thenewlibrary {

    static  Stage addingstage;

    public  static void thenewsongs (HashMap<String,music> libraryMap) {

        addingstage = new Stage();
        addingstage.setTitle("Adding New Songs");
        addingstage.setMinWidth(600);
        addingstage.setMinHeight(450);
        //addingstage.setResizable(true);

        Text forsongtitlebar = new Text("Song Title:");
        //songtitlebar field text area
        TextField songtitlebar = new TextField();
        songtitlebar.setMinWidth(300);
        songtitlebar.setMinHeight(35);
        songtitlebar.setPromptText("Insert the Song Title");

        Text forartistbar = new Text("Artist Name:");
        //artistbar field text area
        TextField artistbar = new TextField();
        artistbar.setMinWidth(300);
        artistbar.setMinHeight(35);
        artistbar.setPromptText("Insert the Artist Name");

        Text forplayingtimebar = new Text("Duration:");
        //playingtimebar field text area
        TextField playingtimebar = new TextField();
        playingtimebar.setMinWidth(300);
        playingtimebar.setMinHeight(35);
        playingtimebar.setPromptText("Insert the Playing time");

        Text forvideofilenamebar = new Text("File type:");
        //videofilenamebar field text area
        TextField videofilenamebar = new TextField();
        videofilenamebar.setMinWidth(300);
        videofilenamebar.setMinHeight(35);
        videofilenamebar.setPromptText("Insert the File type");

        //add button action
        Button addeverythingbtn = new Button("Add to the library");
        addeverythingbtn.setMinWidth(300);
        addeverythingbtn.setMinHeight(35);
        addeverythingbtn.setOnAction(e -> {

            //Validations for empty fields and alphanumeric characters

            if (songtitlebar.getText() == null || songtitlebar.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please insert a song title ");
            }
            else if (!songtitlebar.getText().matches("^[a-zA-Z0-9 ]+$")) {
                JOptionPane.showMessageDialog(null, "Please use only alphanumeric characters in the Name field ");
                 }
            else if (artistbar.getText() == null || artistbar.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please insert a Artist name ");
            }
            else if (!artistbar.getText().matches("^[a-zA-Z0-9 ]+$")) {
                JOptionPane.showMessageDialog(null, "Please use only alphanumeric characters in the Artist field ");
            }
            else if (playingtimebar.getText() == null || playingtimebar.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please insert the Duration");
            }
            else if (!playingtimebar.getText().matches("^[0-9]+$")) {
                JOptionPane.showMessageDialog(null, "Please using integers only ( 1-9) for the duration");
            }
            else if (videofilenamebar.getText() == null || videofilenamebar.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please insert the video file type");
            }
            else if (libraryMap.containsKey(songtitlebar.getText())) {
                JOptionPane.showMessageDialog(null, "This Song already exists in Library");
            }
            else {
                music secondobject =new music();

                secondobject.setSongtitle(songtitlebar.getText());
                secondobject.setArtist(artistbar.getText());
                secondobject.setPlayingtime(Integer.parseInt(playingtimebar.getText()));
                secondobject.setVideofilename(videofilenamebar.getText());
                libraryMap.put(secondobject.getSongtitle(),secondobject);

                JOptionPane.showMessageDialog(null, "The song has been successfully added to the Library ");
            }

        });

        VBox vBoxforbar = new VBox(10);
        //populating vbox
        vBoxforbar.getChildren().addAll(forsongtitlebar,songtitlebar,forartistbar,artistbar,forplayingtimebar,playingtimebar,forvideofilenamebar,videofilenamebar,addeverythingbtn);
        vBoxforbar.setAlignment(Pos.CENTER);

        //populating GridPane with vBox
        GridPane thegridPane =new GridPane();
        thegridPane.add(vBoxforbar, 900 , 900);
        thegridPane.setAlignment(Pos.CENTER);

        Scene scene = new Scene(thegridPane);

        addingstage.setScene(scene);
        addingstage.show();

    }

        }














