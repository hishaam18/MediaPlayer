public class music {

    private String songtitle;
    private String artist;
    private int playingtime;
    private String videofilename;

    //default constructor
    public music() {
        songtitle = "";
        artist = "";
        playingtime = 0;
        videofilename = "";
    }

    public music (String songtitle) {
        this.songtitle = songtitle;
    }


    @Override
    public String toString() {
        return "music{" +
                "songtitle='" + songtitle + '\'' +
                ", artist='" + artist + '\'' +
                ", playingtime=" + playingtime +
                ", videofilename='" + videofilename + '\'' +
                '}';
    }

    public String getSongtitle() {
        return songtitle;
    }

    public void setSongtitle(String songtitle) {
        this.songtitle = songtitle;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public int getPlayingtime() {
        return playingtime;
    }

    public void setPlayingtime(int playingtime) {
        this.playingtime = playingtime;
    }

    public String getVideofilename() {
        return videofilename;
    }

    public void setVideofilename(String videofilename) {
        this.videofilename = videofilename;
    }

    //second constructor
    public music(String title,String artistname,int time,String video) {
        this.songtitle = title;
        this.artist = artistname;
        this.playingtime =time;
        this.videofilename = video;

    }

}