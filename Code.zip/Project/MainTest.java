import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.junit.*;

import java.util.HashMap;

import static org.junit.Assert.*;

public class MainTest{

    //Test For Searching from Library
    @Test
    public void TestForSearching(){
        HashMap<String,music> libraryMap = new HashMap<String, music>();
        int expectedResult = 4364;
        assertEquals(expectedResult,Testing.SearchTest(libraryMap));   //Checking if SearchTest method is returning library size as 4364(which is Number of lines in listofsong file).
    }

    //Test for Refreshing Library Table
    @Test
    public void TestForRefreshingLibrary() {
        ObservableList<music> Songs = FXCollections.observableArrayList();
        assertNotNull(Songs); //checking if Observablelist 'songs' returns null after refreshing
    }

    //Test for Adding new songs in Library
    @Test
    public void TestForAddingSongsToLibrary() {
        HashMap<String, music> libraryMap = Testing.AddSongtoLibrary();

        boolean check;

      if (libraryMap.containsKey("hishaam")) {
          check = true;
      } else {
          check = false;
      }
        assertTrue(check);  //checking if the Hashmap finds the inserted key
    }

    //Test to verify Setter for songtitle
    @Test
    public void testSetsongtitle() {
        music music =new music();
        music.setSongtitle("test");
        assertEquals("songtitle","test", music.getSongtitle() );
    }

    //Test to verify Setter for artist
    @Test
    public void testSetartist() {
        music music =new music();
        music.setArtist("test");
        assertEquals("Artist","test", music.getArtist() );
    }

    //Test to verify Setter for playingtime
    @Test
    public void testSetplayingtime() {
        music music =new music();
        music.setPlayingtime(5);
        assertEquals("Playingtime",5, music.getPlayingtime() );
    }

    //Test to verify Setter for videofilename
    @Test
    public void testSet() {
        music music =new music();
        music.setVideofilename("test");
        assertEquals("Artist","test", music.getVideofilename() );
    }

}

