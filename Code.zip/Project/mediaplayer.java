import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.*;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.swing.*;
import java.io.File;
import java.util.LinkedList;

public class mediaplayer {

    //Declaring
    static boolean muteStatus = false;
    static Stage mediaStage;
    static Media media;
    static MediaPlayer mediaPlayer;
    static MediaView mediaView;
    static File file;
    static Text songName, artistName;
    static Slider trackSlider;

    public static void mediamethod(LinkedList<music> playlist) {

        mediaStage = new Stage();
        mediaStage.setTitle("Media Player");
        mediaStage.setMaximized(true);
        mediaStage.setResizable(false);


        file = new File(playlist.get(0).getVideofilename());
        media = new Media(file.toURI().toString()); //converting link to media readable format

        mediaPlayer = new MediaPlayer(media);

        mediaView = new MediaView(mediaPlayer);
        mediaView.setFitHeight(Screen.getPrimary().getBounds().getHeight() / 10 * 8);

        //Creating Track Slider
        trackSlider = new Slider();
        trackSlider.setMinWidth(850);
        trackSlider.setMaxWidth(850);
        trackSlider.setFocusTraversable(false);
        activateTrackSlider();

        Button playBtn = new Button("Pause");
        playBtn.setMinWidth(100);
        playBtn.setMinHeight(40);
        playBtn.setFocusTraversable(false);
        playBtn.setOnAction(e -> {

            MediaPlayer.Status status = mediaPlayer.getStatus();

            if (status == MediaPlayer.Status.PLAYING) {
                mediaPlayer.pause();
                playBtn.setText("Play");
            } else {
                mediaPlayer.play();
                playBtn.setText("Pause");
            }

        });

        Button stopBtn = new Button("Stop");
        stopBtn.setMinWidth(100);
        stopBtn.setMinHeight(40);
        stopBtn.setFocusTraversable(false);
        stopBtn.setOnAction(e -> {
            mediaPlayer.stop();
        });

        Button nextBtn = new Button("Next");
        nextBtn.setMinWidth(100);
        nextBtn.setMinHeight(40);
        nextBtn.setFocusTraversable(false);
        nextBtn.setOnAction(e -> {
            nextMedia(playlist);
        });

        Button muteBtn = new Button("Mute");
        muteBtn.setMinWidth(100);
        muteBtn.setMinHeight(40);
        muteBtn.setFocusTraversable(false);
        muteBtn.setOnAction(e -> {
            if (!muteStatus) {
                mediaPlayer.setMute(true);
                muteBtn.setText("Unmute");
                muteStatus = !muteStatus;
            } else {
                mediaPlayer.setMute(false);
                muteBtn.setText("Mute");
                muteStatus = !muteStatus;
            }
        });

        Button backBtn = new Button("Back");
        backBtn.setMinWidth(100);
        backBtn.setMinHeight(40);
        backBtn.setFocusTraversable(false);
        backBtn.setOnAction(e -> {
            mediaPlayer.stop();
            mediaStage.close();
            GUI.refreshingPlaylist(playlist);
        });

        Text songText = new Text();
        songText.setText("Song: ");

        songName = new Text();
        songName.setText(playlist.get(0).getSongtitle());

        Text artistText = new Text();
        artistText.setText("        Artist name: ");

        artistName = new Text();
        artistName.setText(playlist.get(0).getArtist());

        HBox playerBox = new HBox();
        playerBox.setAlignment(Pos.CENTER);
        playerBox.getChildren().add(mediaView);

        HBox textBox = new HBox(30);
        textBox.setAlignment(Pos.CENTER);
        textBox.getChildren().addAll(songText, songName, artistText, artistName);

        HBox btnBox = new HBox(20);
        btnBox.setAlignment(Pos.CENTER);
        btnBox.getChildren().addAll(trackSlider, playBtn, stopBtn, nextBtn, muteBtn, backBtn);

        VBox mediaBox = new VBox(20);
        mediaBox.setAlignment(Pos.CENTER);
        mediaBox.getChildren().addAll(playerBox, textBox, btnBox);

        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.add(mediaBox, 0, 0);

        Scene scene = new Scene(gridPane);

        mediaStage.setScene(scene);
        mediaStage.show();

        mediaPlayer.play();
        mediaPlayer.setOnEndOfMedia(() -> {
                    nextMedia(playlist);
                }
        );
    }

    //method to play nextmedia in playlist
    public static void nextMedia(LinkedList<music> playlist) {
        mediaPlayer.stop();
        mediaPlayer.dispose();
        playlist.remove(0);

        if (playlist.size() == 0) {
            mediaStage.close();
            GUI.refreshingPlaylist(playlist);
            JOptionPane.showMessageDialog(null, "No more songs in playlist!\nAdd more songs to play.");
        } else {
            songName.setText(playlist.get(0).getSongtitle());
            artistName.setText(playlist.get(0).getArtist());
            file = new File(playlist.get(0).getVideofilename());
            media = new Media(file.toURI().toString());
            mediaPlayer = new MediaPlayer(media);
            mediaView.setMediaPlayer(mediaPlayer);
            mediaPlayer.play();
            activateTrackSlider();
            mediaPlayer.setMute(muteStatus);
            mediaPlayer.setOnEndOfMedia(() -> {
                        nextMedia(playlist);
                    }
            );
        }
    }

    //method to use trackSlider
    public static void activateTrackSlider() {

        mediaPlayer.setOnReady(() -> {
            trackSlider.setMin(0);
            trackSlider.setMax(mediaPlayer.getMedia().getDuration().toSeconds());
            trackSlider.setValue(0);
        });

        mediaPlayer.currentTimeProperty().addListener(new ChangeListener<Duration>() {
            @Override
            public void changed(ObservableValue<? extends Duration> observableValue, Duration duration, Duration t1) {
                Duration currentTime = mediaPlayer.getCurrentTime();
                trackSlider.setValue(currentTime.toSeconds());
            }
        });

        trackSlider.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                if (trackSlider.isPressed()) {
                    double value = trackSlider.getValue();
                    mediaPlayer.seek(new Duration(value * 1000));
                }
            }
        });

    }

}

