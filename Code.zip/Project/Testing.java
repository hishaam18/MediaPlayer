import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableView;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

public class Testing {

    @Test
    static int SearchTest(HashMap<String, music> librarymap) {

        String filePath = "listofsong";

        try {

            String line;
            BufferedReader reader = new BufferedReader(new FileReader(filePath));

            while ((line = reader.readLine()) != null) {


                //Display on new line  //creating array thearray
                String[] thearray = line.split("\t");

                String songtitle = thearray[0];
                String artist = thearray[1];
                String playingtime = thearray[2];
                String videofilename = thearray[3];


                //create new object and populating with the 4 attributes
                music object = new music(songtitle, artist, Integer.parseInt(playingtime), videofilename);
                librarymap.put(object.getSongtitle(), object);

            } //end while loop

        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return librarymap.size();

    }

    //refresh playlist test
    static ObservableList<music> RefreshLibraryTest (TableView<music> table, HashMap<String, music> libraryMap,ObservableList<music> Songs) {

        table.getItems().clear();

        for (String songTitle : libraryMap.keySet()) {

            Songs.add(libraryMap.get(songTitle));
        }

        table.setItems(Songs);

        return Songs;

    }

    //add songs to library test
    static  HashMap<String,music>AddSongtoLibrary(){
        HashMap<String,music> libraryMap = new HashMap<String, music>();
        music testobject =new music();

        //inserting data into the object
        testobject.setSongtitle("hishaam");
        testobject.setArtist("mr");
        testobject.setPlayingtime(99);
        testobject.setVideofilename("Video file name ");
        libraryMap.put(testobject.getSongtitle(),testobject);

        return libraryMap;

    }


}