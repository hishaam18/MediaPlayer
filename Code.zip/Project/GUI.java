import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import java.util.HashMap;
import java.util.Map;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import java.util.*;
import javax.swing.*;

public class GUI extends Application {

    Stage window;
    static TableView<music> table, tableplaylist;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        //calling readfile method
        HashMap<String, music> libraryMap = Readingfile.readfile();

        // Creating linked list
        LinkedList<music> playlist = new LinkedList<music>();

        //songtitle column
        TableColumn<music, String> songtitleColumn = new TableColumn<>("Title");
        songtitleColumn.setMinWidth(300);
        songtitleColumn.setCellValueFactory(new PropertyValueFactory<>("songtitle"));

        //Artist column
        TableColumn<music, String> artistColumn = new TableColumn<>("Artist");
        artistColumn.setMinWidth(300);
        artistColumn.setCellValueFactory(new PropertyValueFactory<>("artist"));

        //Time
        TableColumn<music, Integer> playingtimeColumn = new TableColumn<>("Time");
        playingtimeColumn.setMinWidth(300);
        playingtimeColumn.setCellValueFactory(new PropertyValueFactory<>("playingtime"));

        //Video file name
        TableColumn<music, String> videofilenameColumn = new TableColumn<>("Video");
        videofilenameColumn.setMinWidth(280);
        videofilenameColumn.setCellValueFactory(new PropertyValueFactory<>("videofilename"));

        //creating table to display all library songs
        table = new TableView<>();
        RefreshingLibraryTable(libraryMap);
        table.setMinWidth(Screen.getPrimary().getBounds().getWidth() / 7 * 5);
        table.setMinHeight(Screen.getPrimary().getBounds().getHeight() / 10 * 9);
        table.getColumns().addAll(songtitleColumn, artistColumn, playingtimeColumn, videofilenameColumn);

        //Table for playlist
        TableColumn<music, String> playlistNameColumn = new TableColumn<>("Playlist");
        playlistNameColumn.setMinWidth(300);
        playlistNameColumn.setCellValueFactory(new PropertyValueFactory<>("songtitle"));

        //creating table to display the linked list - playlist
        tableplaylist = new TableView<>();
        tableplaylist.setMinHeight(Screen.getPrimary().getBounds().getHeight() / 2.5);
        tableplaylist.setItems(createlist(libraryMap));
        tableplaylist.getColumns().addAll(playlistNameColumn);

        refreshingPlaylist(playlist);

        //creating buttons
        //add to playlist button
        Button addtoplaylistbtn = new Button("Add to playlist");
        addtoplaylistbtn.setMinWidth(300);
        addtoplaylistbtn.setMinHeight(35);
        // button action
        addtoplaylistbtn.setOnAction(e -> {  //on pressing this button, selected music is put into
                                             //LinkedList --> 'Playlist'

            music selectedmusic = (music) table.getSelectionModel().getSelectedItem();

           if (playlist.contains(selectedmusic)){
               JOptionPane.showMessageDialog(null, "Song already exist");
            }
            else {
               playlist.add(selectedmusic);
               refreshingPlaylist(playlist);
           }

        });

        //Search field text area
        TextField searchbar = new TextField();
        searchbar.setMinWidth(300);
        searchbar.setMinHeight(35);
        searchbar.setPromptText("Type your search");

        //search button
        Button searchbtn = new Button("Search ");
        searchbtn.setMinWidth(300);
        searchbtn.setMinHeight(35);
        //retrieving text from search field
        searchbtn.setOnAction(e -> { //on pressing search button data in searchbar text field is retrieved
            if (searchbar.getText() == null || searchbar.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please insert a song title ");
            }
            else if (!searchbar.getText().matches("^[a-zA-Z0-9 ]+$")) {
                JOptionPane.showMessageDialog(null, "Please use only alphanumeric characters in the search bar ");
            }
            else {
                searching(searchbar.getText(), libraryMap);
            }
        });

        //addtolibrary Button
        Button addtolibrarybtn =new Button("Add to Library");
        addtolibrarybtn.setMinWidth(300);
        addtolibrarybtn.setMinHeight(35);
        addtolibrarybtn.setFocusTraversable(false);
        addtolibrarybtn.setOnAction(e -> {

            thenewlibrary.thenewsongs(libraryMap);
        } );


        //Refresh button
        Button refreshbtn = new Button("Refresh table");
        refreshbtn.setMinWidth(300);
        refreshbtn.setMinHeight(35);

        //refresh button action
        refreshbtn.setOnAction(e -> {
            RefreshingLibraryTable(libraryMap);
        });

        //play media button
        Button playBtn = new Button("Play Media player");
        playBtn.setMinWidth(300);
        playBtn.setMinHeight(35);
        playBtn.setOnAction(e -> {
            if (playlist.size() != 0) {
                mediaplayer.mediamethod(playlist);
            } else {
                JOptionPane.showMessageDialog(null, "No song in playlist!");
            }
        });

        //Delete Button
        Button deleteBtn = new Button("Delete from playlist");
        deleteBtn.setMinWidth(300);
        deleteBtn.setMinHeight(35);
        deleteBtn.setOnAction(e -> {

            //deleting selected music from playlist
            music selectedmusicfromplaylist = (music) tableplaylist.getSelectionModel().getSelectedItem();

            playlist.remove(selectedmusicfromplaylist);
            tableplaylist.getItems().clear();
            RefreshPlaylistAfterDelete(playlist);

        });

        //Exit Button
        Button exitBtn = new Button("Exit");
        exitBtn.setMinWidth(300);
        exitBtn.setMinHeight(35);
        exitBtn.setOnAction(e -> {
            System.exit(0);
        });

        //Creating 1st vbox to display table
        VBox vBox = new VBox(10);
        //populating vbox
        vBox.getChildren().addAll(table);

        VBox vbox2 = new VBox(25);
        vbox2.setPadding(new Insets(0, 0, 0, 0)); //top, right, bottom, left
        vbox2.setAlignment(Pos.CENTER);
        //populating vbox2
        vbox2.getChildren().addAll(searchbar, searchbtn, addtolibrarybtn, refreshbtn, addtoplaylistbtn, deleteBtn, playBtn, exitBtn);

        VBox vbox3 = new VBox();
        vbox3.setAlignment(Pos.CENTER);
        vbox3.getChildren().addAll(tableplaylist);

        VBox rightPaneBox = new VBox(75);
        rightPaneBox.setAlignment(Pos.CENTER);
        rightPaneBox.setMinWidth(Screen.getPrimary().getBounds().getWidth() / 7);
        rightPaneBox.getChildren().addAll(vbox2, vbox3);

        HBox hbox = new HBox(60);
        hbox.setAlignment(Pos.CENTER); // default TOP_LEFT
        hbox.setPadding(new Insets(30, 30, 30, 30));
        hbox.getChildren().addAll(vBox, rightPaneBox);

        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.add(hbox, 0, 0);

        Scene scene = new Scene(gridPane);

        window = primaryStage;
        window.setMaximized(true);
        window.setTitle("Library");
        window.setScene(scene);
        window.show();
    }

    //search by songtitle method
    public static void searching(String criteria, HashMap<String, music> libraryMap) {

        ObservableList<music> Songs = FXCollections.observableArrayList();

        //searching for matching song title
        libraryMap.forEach((k, v) -> {

            if (k.toLowerCase().contains(criteria.toLowerCase())) {
                Songs.add(v);
            }    //iterating through hashmap to find corresponding songtitle
        });

        if (Songs.isEmpty()) {
            System.out.println("No song found!");
        } else {
            table.getItems().clear();
            table.setItems(Songs);
        }
    }

    //method to reload whole table
    public void RefreshingLibraryTable(HashMap<String, music> libraryMap) {

        ObservableList<music> Songs = FXCollections.observableArrayList();

        table.getItems().clear();

        for (String songTitle : libraryMap.keySet()) {   //reloading Library table

            Songs.add(libraryMap.get(songTitle));
        }

        table.setItems(Songs);

    }

    //Get all of the products
    public ObservableList<music> createlist(HashMap<String, music> libraryMap) {

        ObservableList<music> Songs = FXCollections.observableArrayList();

        for (Map.Entry<String, music> entry : libraryMap.entrySet()) {

            Songs.add(entry.getValue());

        }//end for each

        return Songs;

    }

    public static void refreshingPlaylist(LinkedList<music> playlist) {

        ObservableList<music> Songs = FXCollections.observableArrayList();

        tableplaylist.getItems().clear();

        for (int i = 0; i < playlist.size(); i++) {

            Songs.add(playlist.get(i));
        }

        tableplaylist.setItems(Songs);
    }


    public static void RefreshPlaylistAfterDelete(LinkedList<music> playlist) {

            for(music deletion :playlist) {
                tableplaylist.getItems().add(deletion);
            }

        }


    }







